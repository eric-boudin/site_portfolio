#include <stdio.h>
#include <stdlib.h>
#include "generateurGrille.h"

void partie(int lignes,int colonnes,int xcurseur,int ycurseur){
    int partieEnCours =1;
    int x = xcurseur;
    int y = ycurseur;

    char dep;
    while(partieEnCours){
        while(!kbhit()){
            dep = getchar();
            if (dep == 'z'){
                system("cls");
                x--;
                printf("%d",y);
                break;
            }
            if (dep == 's'){
                system("cls");
                x++;
                break;
            }
            if (dep == 'q'){
                printf("OUI");
                system("cls");
                y--;
                break;
            }
            if (dep == 'd'){
                printf("OUI");
                system("cls");
                y++;
                break;
            }
            afficherGrille(lignes,colonnes,x,y);
        }
    }
}
