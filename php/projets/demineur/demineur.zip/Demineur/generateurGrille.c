#include <stdio.h>
#include <stdlib.h>
#include "partie.h"
#define CURSEUR 'X'

void creationGrille(char *pseudo, int choixPartie){
    int col,lignes,xcurseur = 0, ycurseur=0;
    switch (choixPartie){
        case 1:
            col=9;
            lignes=9;
            break;
        case 2:
            col=16;
            lignes=16;
            break;
        case 3:
            col=16;
            lignes=40;
            break;
    }
    partie(lignes,col,xcurseur,ycurseur);
}

void affichePseudo(char *pseudo){
    int i;
    for(i=0;i<strlen(pseudo);i++){
        printf("%c",pseudo[i]);
        fflush(stdin);
    }

}
void afficherGrille(int lignes, int colonnes,int xcurseur,int ycurseur){
    printf("%d", xcurseur);
    int i,j;
    printf("-");
    for (i=0;i<=lignes;i++){
        printf("-");
    }
    printf("\n");
    for (i=0;i<colonnes;i++){
        printf("|");
        for (j=0;j<lignes;j++){
            if ( i == xcurseur && j==ycurseur){
               printf("%c",CURSEUR);
            }
            else{
                printf("*");
            }
        }
        printf("|\n");
    }

    for (i=0;i<=lignes;i++){
        printf("-");
    }
    printf("-");
}
