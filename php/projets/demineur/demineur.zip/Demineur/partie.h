#ifndef PARTIE_H_INCLUDED
#define PARTIE_H_INCLUDED
void partie(int lignes,int colonnes,int xcurseur,int ycurseur);


#endif // PARTIE_H_INCLUDED
