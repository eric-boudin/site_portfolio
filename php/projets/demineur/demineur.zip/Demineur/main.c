#include <stdio.h>
#include <stdlib.h>
#include "generateurGrille.h"

void creationPartie(char *pseudo){ // Le joueur choisit son pseudo et la difficult�
    int choixPartie = 0;
    printf("Quel est votre nom?\n");
    scanf("%s",pseudo);
    printf("\n");
    printf("Quel mode de difficulte voulez-vous jouer?\n");
    printf("    -Niveau 1 : grille 9x9 a 10 mines\n");
    printf("    -Niveau 2 : grille 16x16 a 40 mines\n");
    printf("    -Niveau 3 : grille 16x40 a 99 mines\n");

    do{
        scanf("%d",&choixPartie);
    }while (choixPartie != 1 && choixPartie != 2 &&choixPartie != 3 );
    creationGrille(pseudo,choixPartie);
}

int main()
{
    char pseudo[10];
    printf("---------Demineur Eric Boudin ---------\n");
    creationPartie(pseudo);
}
