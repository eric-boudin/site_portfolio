#ifndef GENERATEURGRILLE_H_INCLUDED
#define GENERATEURGRILLE_H_INCLUDED

void creationGrille(char *pseudo, int choixPartie);
void affichePseudo(char *pseudo);
void afficherGrille(int lignes, int colonnes,int xcurseur,int ycurseur);

#endif // GENERATEURGRILLE_H_INCLUDED
