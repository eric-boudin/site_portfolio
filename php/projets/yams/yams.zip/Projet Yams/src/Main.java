import logique.Tour;

public class Main {
	public static void main(String[] args) {	
		Tour.lancerPartie();		
	}
}
