package score;
import logique.Participant;

public class Tableau {
	private final int MAXLIGNE=20;
	private final int MAXCOLONE;
	String score[][]; 
	
	public Tableau(Participant[] p) {
		MAXCOLONE = p.length;
		score = new String[MAXCOLONE][MAXLIGNE];
		
		
		
		score[0][0]="Joueur:";
		System.out.println(score[0][0]);
		for (int i=0; i<MAXLIGNE ; i++) {
			for (int j = 0; j<= MAXCOLONE; j++) {
				int k = score[0][0].length();
				int f = 0;
				String e=" ";
				while (f != k) {
					e = e+" ";
					f=f+1;
				}
				score [0][0]= score [0][0]+e+"|";
				}
			}
		
		
		
		System.out.println(score[0][0]);
		//--------------------------------------------------------------------------------
		//remplissageDefaut(score);
		
		for (int i =0; i <= MAXLIGNE; i++) {
			System.out.print("+-");
				for (int k = 0; k<51; k++) {
					System.out.print("-" );  //*52
				}
			
			System.out.print("-");
	
		for (int j = 1; j<= MAXCOLONE; j++) {
			System.out.print("+-");	
				for (int k = 0; k<1; k++) {
					System.out.print("-" );  //*52
				}
								
			System.out.print("-");
			}	
		
			System.out.print("+");
			System.out.print("\n");

			
			
			System.out.print("| ");
			for (int k = 0; k<52; k++) {
			System.out.print(" ");
			}
			
			
			
				for (int j = 1; j<= MAXCOLONE;j++) {
					System.out.print("| ");
					for (int k = 0; k<1; k++) {
						System.out.print("X");
						}
					System.out.print(" ");
					}
			System.out.print("|\n");
		}
	}
	
	public void remplissageDefaut(String score[][]) {
	score[0][0]="Joueur:";
	for (int i=0; i<20 ; i++) {
		for (int j = 1; j<= MAXCOLONE; j++) {
			int k = (52 - (score[j][i].length()))-1;
			int f = 0;
			String e=" ";
			while (f != k) {
				e = e+" ";
				f=f+1;
			}
			score [j][i]= score [j][i]+e+"|";
			}
		}
	}
}
	
/*for (int i =1; i < MAXLIGNE; i++) {
if (i<=6) {
score[0][i]= "total de "+(i);
}
if (i == 8) {
 
	score[0][i]= "total";
} 
if (i == 9) {
	score[0][i]= "Si total des score > 63, alors bonus de 35 points"; //52 caractere
}
if (i == 10) {
	score[0][i]= "Total partie intermediaire"; //52 caractere
}
if (i == 11) {
	score[0][i]= " "; 
}
if (i == 12) {
	score[0][i]= "Brelan (Total des 3 d�s)"; 
}	
if (i == 13) {
	score[0][i]= "Carr� (Total des 4 d�s)"; 
}	
if (i == 14) {
	score[0][i]= "Full (25 points)"; 
}	
if (i == 15) {
	score[0][i]= "Petite Suite (30 points)"; 
}	
if (i == 16) {
	score[0][i]= "Grande Suite (40 points)"; 
}	
if (i == 17) {
	score[0][i]= "Yams (50 points)"; 
}	
if (i == 18) {
	score[0][i]= "Chance (Total des 5 d�s)"; 
}	
if (i == 19) {
	score[0][i]= "Total II"; 
}	
if (i == 20) {
	score[0][i]= "TOTAL: "; 
}	

}
*/
