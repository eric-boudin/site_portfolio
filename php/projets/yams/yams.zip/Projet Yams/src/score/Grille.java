package score;

import javax.swing.JFrame;

import logique.Participant;

public class Grille {
	private final int MAXLIGNE=22;
	private final int MAXCOLONE;
	static String score[][]; 
	
	public Grille(Participant[] p) {
		MAXCOLONE = p.length+1;
		score = new String[MAXCOLONE][MAXLIGNE];
		remplissageDefaut(score);	
	}
	public void remplissageDefaut(String score[][]) {
		score[0][0]= "Joueur:";
		d�cocherParDefaut();
		for (int q=1; q<=6 ;q++) {
					
					score[0][q]= "total de "+q;
					}
					
					 
					score[0][7]= "total";
					score[0][8]= "Si total des score > 63, alors bonus de 35 points"; //52 caractere
					score[0][9]= "Total partie intermediaire"; //52 caractere
					score[0][10]= " "; 
					score[0][11]= "Paire"; 
					score[0][12]= "Double Paire"; 
					score[0][13]= "Brelan (Total des 3 d�s)"; 
					score[0][14]= "Carr� (Total des 4 d�s)"; 
					score[0][15]= "Full (25 points)"; 
					score[0][16]= "Petite Suite (30 points)"; 
					score[0][17]= "Grande Suite (40 points)"; 
					score[0][18]= "Yams (50 points)"; 
					score[0][19]= "Chance (Total des 5 d�s)"; 
					score[0][20]= "Total II"; 
					score[0][21]= "TOTAL: "; 
					
			for (int q=0; q<=21 ;q++) {
					int k = (52 - (score[0][q].length()))-1;
					int f = 0;
					String e=" ";
					while (f != k) {
						e = e+" ";
						f=f+1;			
					}
					score [0][q]= score [0][q]+e;
					
				}
			
			
	}
	public void remplissageLigneJoueur(){
		for (int i = 0; i<MAXCOLONE ; i++) {
			score[i][0]=" "+(i)+" ";
			}
	}
	
	public void afficher(Participant[] p) {
		
		
		for (int i = 0;i<MAXLIGNE ;i++) {
			System.out.print("+");
			for (int k = 0; k<52; k++) {
				System.out.print("-" );  //*52
			}
			System.out.print("+");	
			for(int j = 0;j<MAXCOLONE-1;j++) {
				System.out.print("-----+" ); 
			}
			System.out.println();
			System.out.print("|");
			System.out.print(score[0][i]);
			System.out.print("|");
			for (int k=1; k<=p.length;k++) {
				//score[k][i]="   ";
				remplissageLigneJoueur();			
				System.out.print(" ");
				System.out.print(score[k][i]);
				System.out.print(" |");
												
			}
			System.out.print("\n");
		}
		//AFFICHAGE DERNIERE LIGNE :
						System.out.print("+");
						for (int k = 0; k<52; k++) {
							System.out.print("-" );  //*52
						}
						System.out.print("+");	
						for(int j = 0;j<MAXCOLONE-1;j++) {
							System.out.print("-----+" ); 
						}
				
		//------------------------------------------------------------------------------------------------------------------
	}
	
	public void d�cocherParDefaut() {
		for (int q=0; q<=21 ;q++) {
			for (int j = 1 ;j<5;j++) {
				score[j][q] = "";
				int k = (2 - (score[j][q].length()));
				int f = 0;
				String e=" ";
				while (f != k) {
					e = e+" ";
					f=f+1;			
				}
				score [j][q]= score [j][q]+e;
			}
		}
	}
	
	public static void selection(int num, int idChoix) {
		
		
		score[num+1][idChoix] = "X";
		int k = (5- (score[num+1][idChoix].length()))-1;
		int f = 1;
		String e=" ";
		while (f != k/2) {
			e = e+" ";
			f=f+1;
			}			
			score [num+1][idChoix]= e+score [num+1][idChoix]+e;
			
		
	
}
}
				
