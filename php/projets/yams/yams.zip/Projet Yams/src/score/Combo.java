package score;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.Scanner;

import logique.Des;
import logique.Joueur;
import logique.Participant;

public class Combo {
	public static int valeurPaire1=0;
	public static int valeurPaire2=0;
	public static int brelan=0;
	public static int carre=0;
	public static int[] sommes = new int[6];
	public static int[] sommesAffichage = new int[6];
	public static int yams=0;
	public static int full=0;
	public static int chance = 0;
	public static int petiteSuite=0;
	public static int grandeSuite=0;
	public static int idMembrePaire1;
	public static int idMembrePaire2;
	public ArrayList<Integer> liste = new ArrayList<Integer>();
	public static int indice=0;
	public static int scoreTemp=0;
	public static int bonus=0;
	public static int doublePaire=0;
	
	public Combo(Des des[]) {		
		for (int i = 0; i<des.length;i++) {
			liste.add(des[i].getValeur());
		}
	}
	
	
	public int verifiePaire1() {
		idMembrePaire1=-1;
		idMembrePaire2=-1;
		for(int i=0;i<liste.size()-1;i++) {
			for(int j=0;j<liste.size();j++) {
				if(liste.get(i)==liste.get(j) && i!=j) {
					valeurPaire1=liste.get(i)*2;
					idMembrePaire1=i;
					idMembrePaire2=j;
					return valeurPaire1;
				}
			}
		}
		return 0;
	}

	public int verifiePaire2() { //V�rifie l'existence d'une paire autre que la premi�re.
		if(valeurPaire1!=0) {
			for(int i=0;i<liste.size()-1;i++) {
				for(int j=0;j<liste.size();j++) {
					if(liste.get(i)==liste.get(j) && i!=j && i!=idMembrePaire1 && j!=idMembrePaire2) {
						valeurPaire2=liste.get(i)*2;
						return valeurPaire2;				
					}
				}
			}
		}
		return 7;
	}
	
	//La v�rification de ces trois possibilit�s �tant quasi identiques, elles sont regroup�es dans une seule fonction.
	public int verifieBrelanCarreeYams() {
		int val=0;
		int compteur;
		for(int i=1;i<7;i++) {
			compteur = 0;
			for(int j=0;j<liste.size();j++) {
				if(liste.get(j)==i) {
					val=liste.get(j);
					compteur++;
				}
			}
			switch(compteur) { //On ne peut pas directement renvoyer val car les variables seront utilis�s pour connaitre les choix disponibles plus tard.
				case 3:
					brelan = val*3;
					return brelan;
				case 4: 
					brelan = val*3;//Pour permettre le choix entre carre et brelan plus tard
					carre = val*4;
					return carre;
				case 5:
					brelan = val*3; //Pour permettre les trois choix plus tard
					carre = val*4;
					yams = 50;
					return yams;
			}
		}
		return 0;
	}
	public void verifieSomme() {
		for(int i=0;i<sommes.length;i++) { //Pour �viter des cumuler les scores temporaires d'un tour � l'autre
			sommes[i]=0;
		}
		for(int i=1;i<7;i++) {
			for (int j=0;j<liste.size();j++) {	
				if(liste.get(j)==i) {
					sommes[i-1]=sommes[i-1]+liste.get(j);
				}
			}
		}
	}
	public void verifieFull() {
		verifiePaire1();
		verifiePaire2();
		verifieBrelanCarreeYams();
		if (getBrelan()>0 && getValeurPaire1()>0) {
			full=25;
		}
		else if (getBrelan()>0 && getValeurPaire2()>0) {
			full=25;
		}
		else {
			full = 0;
		}
	}
	public void verifieChance() {
		chance=0;
		for (int i=0;i<liste.size();i++) {
			chance=chance+liste.get(i);
		}
		 
	}
	public void verifieSuite() {
		boolean checkPetite = true;
		boolean checkGrande = true;
		int i=0;
		while((checkPetite || checkGrande) && i<5) {
			if(!liste.contains(i+1))
				checkPetite = false;
			if(!liste.contains(i+2))
				checkGrande = false;
			i++;
		}
		if(checkPetite) {
			petiteSuite = 30;
			grandeSuite = 0;
		}
		else if(checkGrande){
			petiteSuite = 0;
			grandeSuite = 50;
		}
		else {
			petiteSuite = 0;
			grandeSuite = 0;
		}
			
	}	
	
	public int compteurOccurences(int num) {
		int nb=0;
		for(int i=0; i<liste.size();i++) {
			if(liste.get(i)==num) nb++;
		}
		return nb;
	}
	
	public void verifierScore(Participant p,int num) {
		
		Hashtable<Integer,String> scoreDispo = new Hashtable<Integer,String>();
		int optionDispo = 0;
		int reponse = 0;
		
		int numPaire1 = verifiePaire1();
		int numPaire2 = verifiePaire2();
		int numBrelanCarreeYams = verifieBrelanCarreeYams();
		verifieSomme();
		verifieFull();
		verifieChance();
		verifieSuite();
		
		//Rep�re les diff�rents choix dispo
		if (getValeurPaire1() > 0 && !p.getPaire()) {
			System.out.println("Vous avez une paire de: "+(getValeurPaire1()/2));
			optionDispo++;
			scoreDispo.put(optionDispo, "Paire");
		}
			
		if (getValeurPaire2() > 0 && !p.getDoublePaire()) {
			System.out.println("Vous avez une paire de: "+(getValeurPaire2()/2));
			optionDispo++; 
			scoreDispo.put(optionDispo, "Double Paire");
		}
		
		if (getBrelan() > 0 && !p.getBrelan()) {
			System.out.println("Vous avez un brelan de: "+(getBrelan()/3));
			optionDispo++;
			scoreDispo.put(optionDispo, "Brelan");
		}
		if (getCaree() > 0 && !p.getCarre()) {
			System.out.println("Vous avez un caree de: "+(getCaree()/4));
			optionDispo++;
			scoreDispo.put(optionDispo, "Carr�");
		}
		
		for(int i=0;i<sommes.length;i++) {
			if(sommes[i]>0 && !p.getTabSomme()[i]) {
				System.out.println("En sommant les "+(i+1)+" , vous pouvez obtenir "+sommes[i]);
				optionDispo++;
				scoreDispo.put(optionDispo, "Somme de "+(i+1));
			}
		}

		if (getYams() > 0 && !p.getYams()) {
			System.out.println("OUAHHHH vous avez un YAMS de: "+getYams()+" vous pouvez marquer 50 points");
			optionDispo++;
			scoreDispo.put(optionDispo,"Yams");
		}
		if (getFull() > 0 && !p.getFull()) {
			if(((numPaire1!=numBrelanCarreeYams) && (numPaire2!=numBrelanCarreeYams) && (numPaire1!=numPaire2)) || (numPaire1==numPaire2 && numBrelanCarreeYams==numPaire1 && compteurOccurences(numPaire1)==5)) { //Permet d'�viter qu'un tirage type 1-1-1-1-2 soit consid�r� comme un full
				System.out.println("Vous avez un Full vous pouvez marquer 25 points");
				optionDispo++;
				scoreDispo.put(optionDispo,"Full");
			}
		}
		if (getChance() > 0 && !p.getChance()) {
			System.out.println("Avec la Chance vous pouvez marquer: "+getChance());
			optionDispo++;
			scoreDispo.put(optionDispo,"Chance");
		}
		if (getPetiteSuite() > 0 && !p.getPetiteSuite()) {
			System.out.println("Vous avez une petite suite vous pouvez marquer: "+getPetiteSuite());
			optionDispo++;
			scoreDispo.put(optionDispo,"Petite suite");
		}
		if (getGrandeSuite() > 0 && !p.getGrandeSuite()) {
			System.out.println("Vous avez une grande suite vous pouvez marquer: "+getGrandeSuite());
			optionDispo++;
			scoreDispo.put(optionDispo,"Grande suite");
		}
		
		if(!scoreDispo.isEmpty()) {
			for(int i = 0;i<scoreDispo.size();i++) {
				System.out.println((i+1) + " : " + scoreDispo.get(i+1));
			}
			
			if(p instanceof Joueur) {
				System.out.println("Veuillez choisir un score parmi les r�sultats suivants: ");
				boolean repValide = false;			
				while(!repValide) {
					Scanner sc = new Scanner(System.in);
					try{
						reponse = sc.nextInt();
						if(reponse>0 && reponse<=scoreDispo.size()) repValide = true;
						else System.out.println("Choix non valide");
					}catch(InputMismatchException e ) {
						System.out.println("R�ponse non valide.");
					}
				}
			}
			else {
				reponse = scoreDispo.size(); //Prend automatiquement la derni�re possibilit� disponible.				
				//reponse= (int) (1 + (Math.random() * (scoreDispo.size()))); //Choisi une possibilit� au hasard parmi celle disponible
			}
			
			
			
			switch(scoreDispo.get(reponse)) { //Ajoute le score en fonction de l'utilisateur
			
				case "Paire":
					p.setPaire(true);
					p.addScore("normal",valeurPaire1);
					indice=10;
					break;
				case "Double Paire":
					p.setDoublePaire(true);
					p.addScore("normal", getValeurDoublePaire());
					indice=11;
					break;
				case "Brelan":
					p.setBrelan(true);
					p.addScore("normal",brelan);
					indice=12;
					break;
				case "Somme de 1":
					p.setSommeChoisie(true,1);
					p.addScore("temp",sommes[0]);
					indice=0;
					break;
				case "Somme de 2":
					p.setSommeChoisie(true,2);
					p.addScore("temp",sommes[1]);
					indice=1;
					break;
				case "Somme de 3":
					p.setSommeChoisie(true,3);
					p.addScore("temp",sommes[2]);
					indice=2;
					break;			
				case "Somme de 4":
					p.setSommeChoisie(true,4);
					p.addScore("temp",sommes[3]);
					indice=3;
					break;
				case "Somme de 5":
					p.setSommeChoisie(true,5);
					p.addScore("temp",sommes[4]);
					indice=4;
					break;
				case "Somme de 6":
					p.setSommeChoisie(true,6);
					p.addScore("temp",sommes[5]);
					indice=5;
					break;
				case "Yams":
					p.setYams(true);
					p.addScore("normal",yams);
					indice=17;
					break;
				case "Chance":
					p.setChance(true);
					p.addScore("normal",chance);
					indice=18;
					break;
				case "Petite suite":
					p.setPetiteSuite(true);
					p.addScore("normal",petiteSuite);
					indice=15;
					break;
				case "Grande suite":
					p.setGrandeSuite(true);
					p.addScore("normal",grandeSuite);
					indice=16;
					break;
				case "Full":
					p.setFull(true);
					p.addScore("normal",full);
					indice=14;
					break;
				case "Carr�":
					p.setCarre(true);
					p.addScore("normal",carre);
					indice=13;
					break;
			}
			scoreTemp=p.getScoreTemp();
			System.out.println("il vaut:"+scoreTemp);
			
			if(indice!=0) { //On ajoute au tableau seulement si un choix a bien �t� selectionn� par l'utilisateur.
				Grille.selection(num,indice);
				if (indice<=6) {
					Fenetre.selectionSomme(num, indice,scoreTemp,bonus,p.getScore());			
				}
				else {
				Fenetre.selection(num, indice,p.getScore());		
				}	
			}
			System.out.println("Vous avez choisi : "+scoreDispo.get(reponse));
			if(!p.getBonusObtenu() && p.getScoreTemp()>=63) {
				p.addScore("normal",35);
				System.out.println("Votre sous-total est sup�rieur ou �gal � 63 points, vous avez le droit � un bonus de 35 points!");
				p.setBonusObtenu(true);
				bonus=35;
			}
			Fenetre.bonus(num,scoreTemp,bonus,p.getScore());
		}
		
		System.out.println("Votre sous-total vaut: "+p.getScoreTemp());
		System.out.println("Votre score est actuellement de : "+p.getScore());
	}
	
	//Diff�rents getters n�cessaires.
	public static int getIndice() {
		return indice;
	}
	public static int getValeurPaire1() {
		return valeurPaire1;
	}
	public static int getValeurPaire2() {
		return valeurPaire2;
	}
	public static int getValeurDoublePaire() {
		return doublePaire = valeurPaire1 + valeurPaire2;
	}
	public static int getBrelan() {
		return brelan;
	}
	public static int getCaree() {
		return carre;
	}
	public static int[] getSommes() {
		return sommes;
	}
	public static int[] getSommesAffichage() {
		return sommesAffichage;
	}
	public static int getYams() {
		return yams;
	}
	public static int getFull() {
		return full;
	}
	public static int getChance() {
		return chance;
	}
	public static int getPetiteSuite() {
		return petiteSuite;
	}
	public static int getGrandeSuite() {
		return grandeSuite;
	}
	public static int getScoreTemp() {
		return scoreTemp;
	}

}

