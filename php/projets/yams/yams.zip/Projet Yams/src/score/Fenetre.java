package score;



import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import logique.Participant;

//CTRL + SHIFT + O pour g�n�rer les imports
public class Fenetre extends JFrame {
	  static Object[][] data = new Object[21][5];
	  static String  title[] = new String[5];
	  static JTable tableau ;
	  static int[] bonus= new int[4];
	  
public Fenetre(Participant[] p){
	this.setSize(960, 1080);
  this.setLocationRelativeTo(null);
  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  this.setTitle("Score YAMS");

  
  this.setVisible(true);
  for (int q=1; q<4 ;q++) {
	bonus[q]=0;
	}
  //Les donn�es du tableau
  for (int q=0; q<=6 ;q++) {
	data[q][0]= "total de "+(q+1);
	}
 
  data[6][0]= "total";
  data[7][0]= "Si total des score > 63, alors bonus de 35 points"; //52 caractere
  data[8][0]= "Total partie intermediaire:"; //52 caractere
  data[8][1]= "0"; //52 caractere
  data[8][2]= "0" ;//52 caractere
  data[8][3]= "0" ;//52 caractere
  data[8][4]= "0" ;//52 caractere
  data[9][0]= " "; 
  data[10][0]= "Paire"; 
  data[11][0]= "Double Paire"; 
  data[12][0]= "Brelan (Total des 3 d�s)"; 
  data[13][0]= "Carr� (Total des 4 d�s)"; 
  data[14][0]= "Full (25 points)"; 
  data[15][0]= "Petite Suite (30 points)"; 
  data[16][0]= "Grande Suite (40 points)"; 
  data[17][0]= "Yams (50 points)"; 
  data[18][0]= "Chance (Total des 5 d�s)"; 
  data[19][0]= "Total II"; 
  data[20][0]= "TOTAL:";
  //Les titres des colonnes

  
	  
  title[0]="Joueur:";
  title[1]=p[0].getPseudo();
  title[2]=p[1].getPseudo();
  title[3]=p[2].getPseudo();
  title[4]=p[3].getPseudo();
  tableau = new JTable(data, title);
  tableau.setAlignmentX(CENTER_ALIGNMENT);
  //Nous ajoutons notre tableau � notre contentPane dans un scroll
  //Sinon les titres des colonnes ne s'afficheront pas !
  this.getContentPane().add(new JScrollPane(tableau));
	//On indique que l'en-t�te doit �tre au nord, donc au-dessus
	this.getContentPane().add(tableau.getTableHeader(),BorderLayout.NORTH);
	//Et le corps au centre !
	this.getContentPane().add(tableau, BorderLayout.CENTER);
	
	pack();
	tableau.repaint();
 
	
	
}   
	
	public static void selection(int num, int idChoix, int TOTAL) {
		data[idChoix][num+1]="X";

		data[20][num+1]=TOTAL;

		tableau.repaint();
	}
	public static void selectionSomme(int num, int idChoix, int sousTotal, int bonus, int TOTAL) {
		
		
		data[8][num+1]=sousTotal;
		data[idChoix][num+1]="X";
		
		data[19][num+1]=TOTAL-((Integer)data[8][num+1]);
		data[20][num+1]=TOTAL+sousTotal;
		tableau.repaint();
	}
	public static void bonus(int num,int sousTotal,int bonus, int TOTAL) {
		
		data[6][num+1]=sousTotal+bonus;
		data[7][num+1]=bonus;
		data[8][num+1]=sousTotal;
		
		data[19][num+1]=TOTAL;
		data[20][num+1]=TOTAL+sousTotal;
		
		tableau.repaint();
	}
	
			  
}