package logique;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import score.Fenetre;
import score.Grille;

public class Tour {
	private static String reponse="";
	private static Scanner sc;
	private static boolean modeTriche = false;
	private static int nbManches;
	private static boolean partieEnCours = true;
	private static Grille tableau;
	
	public static void lancerPartie() {
		Participant[] p = new Participant[4]; 
		int nbJoueurs = -1;
		
		System.out.println("Etes-vous un tricheur(o/n)?");
		sc = new Scanner(System.in);
		reponse = sc.nextLine();
		if(reponse.toLowerCase().equals("o")) {
			modeTriche = true; 
			System.out.println("Mode triche activ�.");
		}
		
		do {
			System.out.println("Combien de joueurs �tes-vous? (4 maximum)");
			sc = new Scanner(System.in);
			try {
				nbJoueurs = sc.nextInt();
			}catch(InputMismatchException e) {
				System.out.println("Tu sais ce que c'est un chiffre?");
			}
			
		}while(nbJoueurs>=5 || nbJoueurs<0);
		
		System.out.println("Combien de manche voulez-vous?");
		sc = new Scanner(System.in);
		reponse = sc.nextLine();
		try{
			nbManches = Integer.parseInt(reponse);
		}catch (NumberFormatException e) {
			System.out.println("R�ponse invalide le nombre de manches sera donc fix� � 3");
			nbManches = 3;
		}
		
		
		for(int i = 0;i<nbJoueurs;i++) { //Cr�ation des joueurs humains
			System.out.println("Nom du joueur "+(i+1)+": ");
			sc = new Scanner(System.in);
			String nom = sc.nextLine();
			p[i] = new Joueur(nom);
		}
		
		if(nbJoueurs<4) { //Cr�ation du nombres de bots n�cessaires pour atteindre 4 joueurs.
			for(int j =nbJoueurs+1;j<5;j++ ) {
				p[j-1] = new IA();
			}
		}
		Fenetre fenetre = new Fenetre(p);
		for(int i=0;i<nbManches;i++) { //D�but d'une manche
			partieEnCours = true;
 			int nbTour = 1;
			System.err.println("Manche n�"+(i+1));
			
			while(partieEnCours) { 
				System.out.println("-------D�but du tour n�"+ nbTour +"-------"+System.lineSeparator()); 
				tour(p); //Lancement d'un tour
				tableau.afficher(p);
				System.out.println(System.lineSeparator()+"-------Fin du tour n�"+(i+1)+"-------");
				nbTour++;
				for(int j = 0; j<p.length;j++) {
					if(p[j].aFini()) {partieEnCours = false;}
				}
			}
			System.out.println("Le vainqueur est "+getVainqueur(p).getPseudo() +" avec un score de "+ getVainqueur(p).getScore()+".");
			System.out.println("Fin de la manche n�" + (i+1));
		}
		sc.close();
	}
	
	/**
	 * Lance le d�roulement d'un tour.
	 * @param p tableau contenant les joueurs de la partie.
	 */
	private static void tour(Participant[] p) {
			tableau = new Grille(p);
			for(int i = 0;i<p.length;i++) {
				System.out.println(System.lineSeparator()+"---------Lancer de " +p[i].getPseudo()+"---------");
				
				if(!p[i].aFini()) {
					if(p[i] instanceof Joueur) {	
						if(!modeTriche) {
							p[i].reInitNbLancer();
							p[i].jouer();
							do{
								System.out.println("\nVoulez-voulez-vous relancer?(O/N)");
								sc = new Scanner(System.in);
								reponse=sc.nextLine();
								if(reponse.toLowerCase().equals("o")) choixRelance(p[i]);
							}while(reponse.toLowerCase().equals("o") && p[i].getNbLancer()<Participant.getNbLancerMax());
						}
						else {
							int[] valeurs = {0,0,0,0,0};
							for(int j = 0 ;j<5;j++) {
								 do{
									try {
										System.out.println("Veuillez entrez la valeur du d� n�"+(j+1));
										sc = new Scanner(System.in);
										valeurs[j] = sc.nextInt();
									}
									catch(InputMismatchException e) {
										System.out.println("La valeur entr�e n'est pas un chiffre.");
									}
								}while(valeurs[j]<1 || valeurs[j]>6);
							}					
							p[i].setDes(valeurs);
							System.out.println(p[i].afficherLancerDes());
						}
						if(p[i].getNbLancer()==Participant.getNbLancerMax()) System.out.println("\nVous avez �puis� vos lancers pour ce tour.");
					}
					else {
						p[i].reInitNbLancer();
						p[i].jouer();
						//Pour l'instant, le nom de d�s relanc� est au hasard entre 1 et 5
						System.out.println("Relance...");
						ArrayList<Integer> nbARelancer = new ArrayList<Integer>();
						int nb = (int) (1 + (Math.random() * (5 - 1))); //Nombre de d�s a relancer
						for(int j=0 ;j<nb;j++) {
							nbARelancer.add((int) (1 + (Math.random() * (5 - 1)))); //Num�ro du d�s � relancer
						}
						p[i].jouer(listToInt(nbARelancer));
					}
				}
				
				p[i].choisirScore(i);
				if(p[i].aFini()) System.out.println("Vous avez compl�t� le tableau des scores, vous ne pouvez plus jouer.");
				System.out.println("---------Fin lancer de " +p[i].getPseudo()+"---------"+"\n");
				System.out.println(System.lineSeparator()+"Appuyer sur une touche pour passer au joueur suivant.");
				sc = new Scanner(System.in);
				reponse = sc.nextLine();
			}
	}	
	
	/**
	 * Gestion de la relance
	 * @param p participant qui va relancer ses d�s.
	 */
	private static void choixRelance(Participant p) {
		int nb=-1;
		int i = 0;
		ArrayList<Integer> nbARelancer = new ArrayList<Integer>();
		System.out.println("Veuillez entrer les num�ros des d�s � relancer(0 pour arr�ter).");
		do
		try {
			do {
				sc = new Scanner(System.in);
				nb = sc.nextInt();
				if(nb>0 && nb <7) nbARelancer.add(nb);
				i++;
			}while(i<5 && (nb>0||nb<7) && nb!=0 );
		}catch(InputMismatchException e) {
			
		}while(i<5 && (nb>0||nb<7) && nb!=0 );
		p.jouer(listToInt(nbARelancer));
	}
	
	private static Participant getVainqueur(Participant[] p) {
		Participant vainqueur=p[0];
		for (int i=1;i<p.length;i++) {
			if(p[i].getScore() > vainqueur.getScore()) vainqueur = p[i];
		}
		return vainqueur;
	}
	
	/**
	 * Convertit une ArrayList d'integer en tableau de int
	 * @param a ArrayList d'integer
	 * @return tableau d'int.
	 */
	public static int[] listToInt(ArrayList<Integer> a) {
		int[] toInt = new int[a.size()];
		
		for(int i = 0;i<a.size();i++) {
			toInt[i] = a.get(i);
		}
		return toInt;
	}
}
