package logique;

public interface IParticipe {
	public void jouer(int[] numDes);
	public void jouer();
	public String afficherLancerDes();
	public String getPseudo();
	public void reInitNbLancer();
	public int getNbLancer();
	public abstract void choisirScore(int num);
}
