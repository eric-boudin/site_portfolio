package logique;

public class Joueur extends Participant {

	public Joueur(String nom) {
		super(nom);
	}
	
}
