package logique;

import score.Combo;

public abstract class Participant implements IParticipe{

	
	protected String pseudo;
	protected int score;
	protected int scoreTemp;
	protected Des[] des = new Des[5];
	protected int  nbLancer;
	protected static final int NBLANCERMAX = 3;
	private boolean chance = false;
	private boolean yams = false;
	private boolean paire = false;
	private boolean doublePaire = false;
	private boolean brelan = false;
	private boolean carre = false;
	private boolean petiteSuite = false;
	private boolean grandeSuite = false;
	private boolean full = false;
	private boolean bonusObtenu = false;
	private boolean[] tabSomme= new boolean[6];
	
	
	/**
	 * Cr�er un joueur avec le nom pass� en param�tre.
	 * @param nom pseudo du joueur
	 */
	public Participant(String nom) {
		pseudo = nom;
		score = 0;
		scoreTemp=0;
		for (int i =0; i<des.length; i++) {
			des[i]=new Des();
		}
	}
	
	/**
	 * Joueur par d�faut.
	 */
	public Participant() {
		this("Joueur");
	}


	/**
	 * Permet un joueur de jouer son tour.
	 */
	@Override
	public void jouer(int[] numDes) {
		if(nbLancer < NBLANCERMAX) {
			for(int i = 0; i < numDes.length; i++) {
				des[numDes[i]-1].lancerDes();
				//else des[numDes[i-1]].lancerDes();
			}
			System.out.println(afficherLancerDes());
			nbLancer++;
		}
		else {
			System.out.println("D�sol�, vous avez �puis� tous vos lancers pour ce tour.");
		}
	}

	@Override
	public void jouer(){
		int[] desARelancer = {1,2,3,4,5};
		jouer(desARelancer);
	}
	
	
	/**
	 * Permet de choisir le score en fonction des d�s tir�s
	 */
	@Override
	public void choisirScore(int num) {
		Combo c = new Combo(des);	
		c.verifierScore(this,num);	
		
	}

	@Override
	public String getPseudo() {
		return pseudo;
	}

	@Override
	public String afficherLancerDes() {
		String s="";
		for(int j=0;j<des.length;j++) {
			s += "D� n� "+(j+1)+": "+des[j].toString();
			if(j<des.length-1) s+=System.lineSeparator();
		}
		return s;
	}


	@Override
	public void reInitNbLancer() {
		nbLancer = 0;
	}


	@Override
	public int getNbLancer() {
		return nbLancer;
	}
	
	public void setDes(int[] valeurs) {
		for(int i =0;i<des.length;i++) {
			des[i].setValeur(valeurs[i]);
		}
	}
	
	public static int getNbLancerMax() {
		return NBLANCERMAX;
	}

	public boolean getChance() {
		return chance;
	}

	public boolean getYams() {
		return yams;
	}
	
	public boolean[] getTabSomme() {
		return tabSomme;
	}
	
	public boolean getPaire() {
		return paire;
	}
	
	public boolean getDoublePaire() {
		return doublePaire;
	}
	
	public boolean getBrelan() {
		return brelan;
	}
	
	public boolean getCarre() {
		return carre;
	}
	
	public boolean getPetiteSuite() {
		return petiteSuite;
	}
	
	public boolean getGrandeSuite() {
		return grandeSuite;
	}
	
	public boolean getFull() {
		return full;
	}
	public boolean getBonusObtenu() {
		return bonusObtenu;
	}
	public void setChance(boolean b) {
		chance = b;
	}
	
	public void setYams(boolean b) {
		yams = b;
	}
	
	public void setSommeChoisie(boolean b,int numSomme) {
		tabSomme[numSomme-1]=b;
	}
	
	public void setPaire(boolean b) {
		paire = b;
	}
	
	public void setDoublePaire(boolean b) {
		doublePaire = b;
	}
	
	
	public void setBrelan(boolean b) {
		brelan = b;
	}
	
	public void setCarre(boolean b) {
		carre = b;
	}
	
	public void setPetiteSuite(boolean b) {
		petiteSuite = b;
	}
	
	public void setGrandeSuite(boolean b) {
		grandeSuite = b;
	}
	
	public void setFull(boolean b) {
		full = b;
	}
	
	public void setBonusObtenu(boolean b) {
		bonusObtenu=b;
	}
	
	public int getScore() {
		return score;
	}
	
	public int getScoreTemp() {
		return scoreTemp;
	}
	
	public void addScore(String type,int... score) { //Ajoute le score du tour dans la variable score correspondant au bon type.
		for(int i = 0;i<score.length;i++) {
			if(type.equals("normal")) this.score += score[i];
			else if (type.equals("temp")) this.scoreTemp += score[i];
		}
	}

	public void addScoreTemp(int... score) {
		
	}
	
	public boolean aFini() {
		boolean sommes = true;
		int i = tabSomme.length;
		while(i>0 && sommes) {
			if(!tabSomme[i-1]) sommes=false;
			i--;
		}
		return paire && doublePaire && brelan && carre && yams && full && chance && sommes && petiteSuite && grandeSuite;
	}
	
}
