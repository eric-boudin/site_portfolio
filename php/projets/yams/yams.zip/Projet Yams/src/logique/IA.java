package logique;

import java.util.Hashtable;

public class IA extends Participant{
	private static int nbIA = 0;
	
	public IA() {
		super("Ordi "+(nbIA+1));
		nbIA++;		
	}	
	
}
