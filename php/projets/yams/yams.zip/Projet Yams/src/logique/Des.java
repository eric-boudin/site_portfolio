package logique;

public class Des{
	private int valeur;
	
	public Des() {
		
	}
	
	/**
	 * Lance le d�s.
	 */
	public void lancerDes() {
		valeur = (int) (1 + (Math.random() * (6))); //Gen�re un nombre entre 1 et 6.
	}
	
	/**
	 * R�cup�re la valeur du d�s.
	 * @return valeur contient la valeur du d�s.
	 */
	public int getValeur() {
		return valeur;
	}
	
	public void setValeur(int valeur) {
		this.valeur = valeur;
	}
	
	
	/**
	 * Retourne la valeur du d�s sous forme de cha�ne de caract�res.
	 */
	public String toString() {
		return "La valeur du d� est "+valeur+".";
	}
	
}
